NewsBlock WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.4 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.3 - April 18 2018 =
 * Fixed path to customizer.js
 
= 1.2 - March 22 2018 =
* Fixed scripts path in child themes

= 1.1 - July 18 2017 =
* Fixed translated texts
* Added Featured Image for single posts
* Added Favicon option for Theme Settings

= 1.0 - April 25 2017 =
* Initial release

== Features for Pro Version Only ==
* Unlimited Theme Color Options
* Google Fonts Options
* Sticky Header Navigation
* Header Advertisement Area
* Post Block Advertisement Area
* Footer Advertisement Area
* Display Excerpt on Post Block
* Social Share on Post Block
* Social Share on Single Post
* Author Avatar on Single Post
* Author Info Box on Single Post
* Related Post on Single Post
* Newsletter Subscribe Widget
* Advertisement Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* "Back to top" button on site bottom
* Footer Text/Copyright Editor