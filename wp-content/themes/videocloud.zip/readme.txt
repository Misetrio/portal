VideoCloud WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.1 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.0 - May 23, 2017 =
* Initial release