VideoHost WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.5 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.4 - May 12 2018 =
* Fixed incorrect posts thumbnail

= 1.3 - April 18 2018 =
 * Fixed path to customizer.js
 
= 1.2 - March 23 2018 =
* Fixed display issues for multiple videos on single post

= 1.1 - March 22 2018 =
* Fixed scripts path in child themes

= 1.0 - September 18, 2017 =
* Initial release

== Features for Pro Version Only ==
* Unlimited Theme Color Options
* Google Fonts Options
* Home Recent Videos with Pagination
* Sticky Site Header
* Number Option for Featured Slides
* Homepage Advertisement Area
* Video Duration on Video Thumbnail
* Display Category on Category Block
* Number of Videos on Category Block 
* Breadcrumbs on Single Post
* Post Likes Icon on Single Post
* Share icons on Single Post
* Author Info Box on Single Post
* Related Videos on Single Post
* Author Avatar  on Single Post
* Newsletter Subscribe Widget
* Advertisement Widget
* Social Media Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* "Back to top" button on site bottom
* Footer Widgets Area
* Footer Text/Copyright Editor