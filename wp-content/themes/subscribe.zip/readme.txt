Subscribe WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.1 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.0.2 - May 03 2018 =
* Fixed Home Service A widget to avoid breaking the page layout

= 1.0.1 - May 03 2018 = 
* Removed default appearance of HTML elements
* Fixed pre-load effects
* Fixed mobile menu icon

= 1.0 - April 30 2018 = 
* Initial release

Button Shortcode Usage:

[button color="blue" title="Your Button Title" subtitle="Version 1.0.1 - Mac OSX" url="#"]

Button Color Options: 

blue, green, orange, yellow, purple, white, black

* "subtitle" is optional