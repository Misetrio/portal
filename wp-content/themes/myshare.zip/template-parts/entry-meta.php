<div class="entry-meta clear">

	<span class="entry-author"><?php the_author_posts_link(); ?></span> 
	<span class="entry-date"> &#8212; <?php echo get_the_date(); ?></span>

	<span class="entry-category"> <?php esc_html_e('in', 'myshare'); ?> <?php myshare_first_category(); ?></span>

</div><!-- .entry-meta -->