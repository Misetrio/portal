<?php
	the_posts_pagination( array( 'prev_text' => __( '&laquo; Previous', 'course' ), 'next_text' => __( 'Next &raquo;', 'course' ) ) );
?>