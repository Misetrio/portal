<?php if ( !empty( $instance['top_right_ad_code'] ) ) : ?>

	<div class="column-three">
		<?php echo ( $instance['top_right_ad_code'] ); ?>
	</div><!-- .column-three -->

<?php endif; ?>