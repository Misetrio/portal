<div class="entry-meta clear">
	<span class="entry-date"><?php echo get_the_date(); ?></span>
	<span class="entry-comment-number"><?php comments_popup_link( '0', '1', '%', 'comments-link', ''); ?></span>
</div><!-- .entry-meta -->