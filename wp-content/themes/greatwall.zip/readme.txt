GreatWall Pro WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.5 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.4 - May 03 2018 =
 * Fixed bxslider link clicking for Firefox 59

= 1.3 - May 02 2018 =
 * Fixed Home Service A widget to avoid breaking the page layout

= 1.2 - April 18 2018 =
 * Fixed path to customizer.js

= 1.1 - March 22 2018 =
 * Fixed scripts path in child themes

= 1.0 - March 05 2018 =
* Initial release

== Pro Version Only ==
* Unlimited Theme Color Options
* Google Fonts Options
* E-Commerce / WooCommerce Store
* Home Facts Widget
* Home Service Type B Widget
* Home Timeline Events Widget
* Home Pricing Table Widget
* Home Clients Widget
* Posts Loop Layout Styles -> Blog/Grid/List
* Featured Posts Number 3/Unlimited
* Sticky Header Navigation
* Breadcrumbs on Single Post
* Social Share on Single Post
* Author Info Box on Single Post
* Related Post on Single Post
* Advertisement Widget
* Contact Info Widget
* Newsletter Subscribe Widget
* Social Media Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* "Back to top" button on site bottom
* Footer Text/Copyright Editor