MyShare WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.3 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.2 - April 18 2018 =
 * Fixed path to customizer.js

= 1.1 - March 22 2018 =
* Fixed scripts path in child themes

= 1.0 - August 22 2017 =
* Initial release

== Features for Pro Version Only ==
* Unlimited Theme Color Options
* Google Fonts Options
* Sticky Header Navigation
* Post Likes on Home & Single Post
* Social Share on Home & Single Post
* Author Avatar on Post Meta
* Author Info Box on Single Post
* Related Posts on Single Post
* Newsletter Subscribe Widget
* Advertisement Widget
* Social Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* "Back to top" button on site bottom
* Footer Social Icons
* Footer Text/Copyright Editor