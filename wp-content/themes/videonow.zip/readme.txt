VideoNow WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.9 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.8 - April 18 2018 =
 * Fixed path to customizer.js

= 1.7 - March 23 2018 =
* Fixed display issues for multiple videos on single post

= 1.6 - March 22 2018 =
* Fixed scripts path in child themes

= 1.5 - July 18 2017 =
* Fixed translated texts
* Added Favicon option for Theme Settings

= 1.4.1 - May 1, 2017 =
* Removed unused local webfonts from CSS

= 1.4 - April 29, 2017 =
* Fixed ".aligncenter" class issue

= 1.3 - April 25, 2017 =
* Added Advertisement widget
* Added Ad widget area: Header Ad & Footer Ad
* Added header search for responsive layout
* Fixed responsive issue for single page

= 1.2 - April 24, 2017 =
* Fixed responsive issue for archive page

= 1.1 - March 28, 2017 =
* Fixed bugs

= 1.0 - December 12, 2016 =
* Initial release

== Features for Pro Version Only ==
* Sticky Site Header
* Homepage Advertisement Area
* Header Advertisement Area
* Footer Advertisement Area
* Image Icon for Category Block
* Video Duration on Video Thumbnail
* Display Excerpt for Video Loop
* Display Category for Video Loop
* Number Option for Video Loop
* Related Videos on Single Post
* Author Avatar  on Single Post
* Category Description on Archive Page
* Advertisement Widget
* Social Media Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* Footer Text/Copyright Editor
