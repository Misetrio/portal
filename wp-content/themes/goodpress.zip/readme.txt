GoodPress WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.4 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.3 - May 03 2018 =
 * Fixed bxslider link clicking for Firefox 59

= 1.2 - April 18 2018 =
 * Fixed path to customizer.js

= 1.1 - March 22 2018 =
 * Fixed scripts path in child themes

= 1.0 - March 21 2018 =
* Initial release