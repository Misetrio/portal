<?php get_header(); ?>
	
	<div id="primary" class="content-area">

		<main id="main" class="site-main clear">

			<?php
				get_template_part('sidebar', '2');
			?>

			<div id="recent-content" class="has-sidebar-2">

				<?php
					get_template_part('template-parts/content', 'featured');
				?>
						
				<?php if ( get_theme_mod('home-recent-on', 'true') == true ) { ?>

				<div class="most-recent-content">

					<div class="section-heading">

						<?php
							$heading_text = get_theme_mod('recent-heading', __('Recent Posts', 'course'));
						?>

						<h3 class="section-title">
							<?php echo $heading_text; ?>
						</h3>

						<div class="recent-nav">
							<span class="nav-left">
								<?php previous_posts_link( '' . __('Prev', 'course')); ?>
							</span>

							<span class="nav-right">
								<?php next_posts_link( __('Next', 'course') . '', 0 ); ?>
							</span>
						</div><!-- .recent-nav -->

					</div><!-- .section-heading -->	

					<div class="content-grid clear">

						<?php

						$temp = $wp_query;
						$wp_query= null;
						$wp_query = new WP_Query( );
						$wp_query->query(
							array( 
								'post__not_in' => get_option( 'sticky_posts' ), 
								'paged' => $paged 
							)
						);

						if ( $wp_query->have_posts() ) :	
						
						$i = 1;

						/* Start the Loop */
						while ( $wp_query->have_posts() ) : $wp_query->the_post();

							get_template_part('template-parts/content', 'grid');

							if ( $i % 2 == 0 ) {
								echo '<span class="line"></span>';
							}

							$i++;

						endwhile;

						else :

							get_template_part( 'template-parts/content', 'none' );

						endif; 

						?>

					</div><!-- .content-grid -->

				</div><!-- .most-recent-content -->

				<?php } ?>

				<?php 
						
					get_template_part( 'template-parts/pagination', '' ); 
						
					$wp_query = null; $wp_query = $temp;

				?>

			</div><!-- #recent-content -->		

		</main><!-- .site-main -->
		
	</div><!-- #primary -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>
