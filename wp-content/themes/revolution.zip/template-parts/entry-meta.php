<div class="entry-meta">

	<span class="entry-author"><?php the_author_posts_link(); ?></span> 
	<span class="entry-date"><?php echo get_the_date(); ?></span>
	<span class="entry-comment"><?php comments_popup_link( __('0 Comment','revolution'), __('1 Comment', 'revolution'), '% Comments', 'comments-link', __('comments off', 'revolution'));?></span>

</div><!-- .entry-meta -->