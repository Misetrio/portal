Advanced Magazine WordPress Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.5 - May 25 2018 =
* Fixed css issue of comment form label 

= 1.4 - May 02 2018 =
* Fixed bxslider link clicking for Firefox 59

= 1.3 - April 18 2018 =
* Fixed path to customizer.js

= 1.2 - March 22 2018 =
* Fixed scripts path in child themes

= 1.1 - August 28 2017 =
* Fixed loading issue of featured slider
* Fixed hover issue of featured slider (on Google Chrome) 

= 1.0 - August 08 2017 =
* Initial release

== Features for Pro Version Only ==
* Unlimited Theme Color Options
* Unlimited Navigation Bar colors
* Google Fonts Options
* Sticky Header Navigation
* Left logo with Ad banner
* Center logo with quotes
* Content Blocks -> One / Two / Three / Four Columns
* Homepage Advertisement Area
* Header Advertisement Area
* Content Advertisement Area
* Ribbon on Featured Content
* Advertisement on Single Post
* Author Avatar on Single Post
* Social Share on Single Post
* Author Info Box on Single Post
* Author Avatar on Post Meta
* Related Post on Single Post
* Newsletter Subscribe Widget
* Social Media Widget
* Popular Posts Thumbnail Widget
* Recent Posts Thumbnail Widget
* Random Posts Thumbnail Widget
* Most Viewed Posts Thumbnail Widget
* "Back to top" button on site bottom
* Site Footer Style -> Light / Dark
* Footer Navigation Menu
* Footer Text/Copyright Editor